function openCity(cityName, val) {
   var i;
   var x = document.getElementsByClassName("city");
   for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
   }
  
   var activated_tab = document.getElementsByClassName("nav-tab-active"); 
   activated_tab[0].classList.remove("nav-tab-active");
   document.getElementById(cityName).style.display = "block";  
   val.classList.add("nav-tab-active");
}
  
jQuery('.checkAll').click(function(e){
   var table= jQuery(e.target).closest('table');
   jQuery('td input:checkbox',table).prop('checked',this.checked);
   jQuery(".checkAll").prop("checked", this.checked);
});
  
jQuery(".checkboxes").click(function(){
   var numberOfCheckboxes = jQuery(".checkboxes").length;
   var numberOfCheckboxesChecked = jQuery('.checkboxes:checked').length;
   if(numberOfCheckboxes == numberOfCheckboxesChecked) {
      jQuery(".checkAll").prop("checked", true);
   } else {
      jQuery(".checkAll").prop("checked", false);
   }
});

function toNextStep() {
   if(document.getElementById("id_form_subject").value==""){
      document.getElementById("subject_warning").style.display = "block";
   } else {
      if(document.getElementById("id_form_type").value==0) {
         document.getElementById("id_form_submit").submit();
      } else {
         document.getElementById("id_main_form_info").style.display = "none";  
         document.getElementById("id_set_title").style.display = "block"; 
      }
   }   
}

tinymce.init({
   selector: 'textarea#editor',  //Change this value according to your HTML
   auto_focus: 'element1',
   width: "400",
   height: "400"
});