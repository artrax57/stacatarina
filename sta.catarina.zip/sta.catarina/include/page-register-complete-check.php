<?php
    /*
    * Template name:Page Register Complete
    */
    get_header();
?>

<style>
    #colophon {
      display: none;
    }

    #masthead {
      display: none;
    }

    .page:not(.home) #content {
      padding: 0 !important;
    }
</style>

<?php
    $form_path  = $_GET['path'];
    $sql        = "SELECT * FROM wp3t_catarina_forms WHERE form_path='".$form_path."'";
    $result     = $wpdb->get_results($sql, OBJECT);
    
    if(count($result) > 0) {
        $form_name  = $result[0]->form_name;
        $form_path  = $result[0]->form_path;
        $page_title = $result[0]->page_title;
    } 
?>  
<main id="site-content" role="main" style="height:100vh; overflow-y:auto; overflow-x:hidden">
    <div class="row gx-0 h-100">
      <div class="panel-left col col-12 col-sm-4 col-md-5 col-xxl-auto bg-primary">
        <div class="h-100 py-4 py-lg-5 d-flex flex-column">
          <img class="d-block m-auto pr-xl-5 logo" src="/wp-content/uploads/2020/11/escudo.png" />
          <div class="h-100 d-flex flex-column justify-content-center px-3 px-xl-5 mx-xxl-5">
            <section class="px-2 px-md-4 px-xl-5 text-white static-lateral">
              <?php
                echo str_replace("\&quot;", "", $page_title);
              ?>
              <!-- <p class="mb-2">
                <strong>
                  #StaCatarina
                  <br>
                  <span style="color: #F2994A">
                    JUNTOS
                  </span>
                  <br>
                  Prevenir está en <br>
                  nuestras MANOS.
                </strong>
              </p>
              <p style="line-height: 10px;" class="mb-0"><small>
                  Ayúdanos a prevenir el contagio<br>
                  del Coronavirus <strong>COVID 19</strong>.
                </small></p> -->
            </section>
          </div>
          <div class="d-none d-sm-block">
            <p class="rights text-white text-center mb-0 px-3">
              <small>
                © Todos los Derechos Reservados 2020 Alcaldía Santa Catarina, Nuevo León
              </small>
            </p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="row h-100 align-items-center justify-content-center">
          <div class="col col-10 col-xl-7">
            <?php if(isset($response['response']['code']) && $response['response']['code'] == "200") {?>
            <h3 style="color: #4CAF50;"><?php echo $msg; ?></h3>
            <?php } else if(isset($response['response']['code']) && $response['response']['code'] != "200") {?>
            <h3 style="color: red;"><?php echo $msg; ?></h3>
            <?php }?>
            <h3></h3>
            <div id="cincomerca-stacatarina-forms" style="text-align: center;">
              <img width="191" height="183" src="https://pruebasdeapps.online/wp-content/uploads/2020/11/gym-1.png" class="attachment-medium size-medium" alt="" loading="lazy" sizes="100vw">
              <h3 style="font-size: 29px; color: #000000; font-weight: bolder;">¡Enhorabuena!</h3>
              <p style="text-align: center; margin-bottom: 40px;"><span style="color: #000000; text-align: center;">Tu registro ha sido éxitoso.</span></p>
              <a href="https://pruebasdeapps.online/<?php echo $form_path; ?>" style="background-color: #052C9B; border-radius: 30px 30px 30px 30px; padding: 19px 19px 19px 19px;" role="button">
                <span class="elementor-button-content-wrapper">
                  <span class="elementor-button-text" style="color: white;">De Acuerdo</span>
                </span>
              </a>
            </div>
          </div>
        </div>
        <div class="d-block d-sm-none">
          <p class="rights text-muted text-center mb-2 px-3">
            <small>
              © Todos los Derechos Reservados Alcaldía Santa Catarina, Nuevo León
            </small>
          </p>
        </div>
      </div>
    </div>
  </main>
<?php
	get_footer();