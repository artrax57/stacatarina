<?php
    if(isset($_POST['submitIntegromatLinks'])) {
        $simple_form_link       = $_POST['simple_form_link'];
        $complete_form_link     = $_POST['complete_form_link'];
        
        $sql = "SELECT * FROM ".$table_prefix."integromat";
        $result = $wpdb->get_results($sql, OBJECT);

        if(count($result)>0) {
            $sql = "UPDATE ".$table_prefix."integromat ";
            $sql .= "SET simple_form_link='$simple_form_link'";
            $sql .= ", complete_form_link='$complete_form_link'";
            $sql .= " WHERE integromat_id=1";
            $wpdb->query($wpdb->prepare($sql));
        } else {
            $wpdb->insert($table_prefix.'integromat', array(
                'simple_form_link'      => $simple_form_link,
                'complete_form_link'   	=> $complete_form_link
                )
            );
        }        
    }

    function integromat() {
        ?>
        <h2>Integromat Webhooks</h2>
        <div style="width: 100%;">
            <?php
                global $table_prefix, $wpdb;
                $sql = "SELECT * FROM ".$table_prefix."integromat";
                $result = $wpdb->get_results($sql, OBJECT);
            ?>
            <form action="" method="POST">
                <label for="">Formulario simple: </label>
                <input type="text" name="simple_form_link" style="width: 500px;" id="" value="<?php if(count($result)>0) echo $result[0]->simple_form_link;?>"><br>
                <label for="">Formulario completo: </label>
                <input type="text" name="complete_form_link" style="width: 500px;" id="" value="<?php if(count($result)>0) echo $result[0]->complete_form_link;?>"><br>
                <input type="submit" name="submitIntegromatLinks" id="" value="SUBMIT">
            </form>
        </div>
        <?php
    }
?>