<?php
    /*
    * Template name:Page Confirmación
    */
    get_header();
?>

<style>
    #colophon {
      display: none;
    }

    #masthead {
      display: none;
    }

    .page:not(.home) #content {
      padding: 0 !important;
    }
</style>

  
<main id="site-content" role="main" style="height:100vh; overflow-y:auto; overflow-x:hidden">
    <div class="row gx-0 h-100">
      <div class="panel-left col col-12 col-sm-4 col-md-5 col-xxl-auto bg-primary">
        <div class="h-100 py-4 py-lg-5 d-flex flex-column">
          <img class="d-block m-auto pr-xl-5 logo" src="/wp-content/uploads/2020/11/escudo.png" />
          <div class="h-100 d-flex flex-column justify-content-center px-3 px-xl-5 mx-xxl-5">
            <section class="px-2 px-md-4 px-xl-5 text-white static-lateral">
              <?php
                echo str_replace("\&quot;", "", $page_title);
              ?>
              <p class="mb-2">
                <strong>
                  #StaCatarina
                  <br>
                  <span style="color: #F2994A">
                    JUNTOS
                  </span>
                  <br>
                  Prevenir está en <br>
                  nuestras MANOS.
                </strong>
              </p>
              <p style="line-height: 10px;" class="mb-0"><small>
                  Ayúdanos a prevenir el contagio<br>
                  del Coronavirus <strong>COVID 19</strong>.
                </small></p>
            </section>
          </div>
          <div class="d-none d-sm-block">
            <p class="rights text-white text-center mb-0 px-3">
              <small>
                © Todos los Derechos Reservados 2020 Alcaldía Santa Catarina, Nuevo León
              </small>
            </p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="row h-100 align-items-center justify-content-center">
          <div class="col col-10 col-xl-7">
			<?php
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/page/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End the loop.
			?>
        </div>
        <div class="d-block d-sm-none">
          <p class="rights text-muted text-center mb-2 px-3">
            <small>
              © Todos los Derechos Reservados Alcaldía Santa Catarina, Nuevo León
            </small>
          </p>
        </div>
      </div>
    </div>
  </main>
<?php
	get_footer();