<html lang="es" class="js svg background-fixed"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">

<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<title>registro-gimnasio-centro – Demo Cruz</title>
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//s.w.org">
<link href="https://fonts.gstatic.com" crossorigin="" rel="preconnect">
<link rel="alternate" type="application/rss+xml" title="Demo Cruz » Feed" href="/feed/">
<link rel="alternate" type="application/rss+xml" title="Demo Cruz » Feed de los comentarios" href="/comments/feed/">
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/pruebasdeapps.online\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.3"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="/wp-includes/js/wp-emoji-release.min.js?ver=5.5.3" type="text/javascript" defer=""></script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="dashicons-css" href="/wp-includes/css/dashicons.min.css?ver=5.5.3" media="all">
<link rel="stylesheet" id="admin-bar-css" href="/wp-includes/css/admin-bar.min.css?ver=5.5.3" media="all">
<link rel="stylesheet" id="wp-block-library-css" href="/wp-includes/css/dist/block-library/style.min.css?ver=5.5.3" media="all">
<link rel="stylesheet" id="wp-block-library-theme-css" href="/wp-includes/css/dist/block-library/theme.min.css?ver=5.5.3" media="all">
<link rel="stylesheet" id="contact-form-7-css" href="/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.3" media="all">
<link rel="stylesheet" id="wpcf7-redirect-script-frontend-css" href="/wp-content/plugins/wpcf7-redirect/build/css/wpcf7-redirect-frontend.min.css?ver=5.5.3" media="all">
<link rel="stylesheet" id="wpforms-admin-bar-css" href="/wp-content/plugins/wpforms-lite/assets/css/admin-bar.min.css?ver=1.6.3.1" media="all">
<link rel="stylesheet" id="twentyseventeen-fonts-css" href="https://fonts.googleapis.com/css?family=Libre+Franklin%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C800%2C800i&amp;subset=latin%2Clatin-ext&amp;display=fallback" media="all">
<link rel="stylesheet" id="twentyseventeen-style-css" href="/wp-content/themes/twentyseventeen/style.css?ver=20190507" media="all">
<link rel="stylesheet" id="twentyseventeen-block-style-css" href="/wp-content/themes/twentyseventeen/assets/css/blocks.css?ver=20190105" media="all">
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentyseventeen-ie8-css'  href='/wp-content/themes/twentyseventeen/assets/css/ie8.css?ver=20161202' media='all' />
<![endif]-->
<script src="/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp" id="jquery-core-js"></script>
<!--[if lt IE 9]>
<script src='/wp-content/themes/twentyseventeen/assets/js/html5.js?ver=20161020' id='html5-js'></script>
<![endif]-->
<link rel="https://api.w.org/" href="/wp-json/"><link rel="alternate" type="application/json" href="/wp-json/wp/v2/pages/37"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 5.5.3">
<link rel="canonical" href="/registro-gimnasio-centro/">
<link rel="shortlink" href="/?p=37">
<link rel="alternate" type="application/json+oembed" href="/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fpruebasdeapps.online%2Fregistro-gimnasio-centro%2F">
<link rel="alternate" type="text/xml+oembed" href="/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fpruebasdeapps.online%2Fregistro-gimnasio-centro%2F&amp;format=xml">
<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><style media="print">#wpadminbar { display:none; }</style>
	<style media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>
	</head>

<body class="page-template page-template-page-register-complete page-template-page-register-complete-php page page-id-37 logged-in admin-bar wp-embed-responsive has-header-image page-two-column colors-light customize-support">
	<script>
		(function() {
			var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

				request = true;
	
			b[c] = b[c].replace( rcs, ' ' );
			// The customizer requires postMessage and CORS (if the site is cross domain).
			b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
		}());
	</script>
  
  <div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Saltar al contenido</a>

	<header id="masthead" class="site-header" role="banner">

		<div class="custom-header" style="margin-bottom: 0px;">

		<div class="custom-header-media">
			<div id="wp-custom-header" class="wp-custom-header"><img src="/wp-content/themes/twentyseventeen/assets/images/header.jpg" width="2000" height="1200" alt="Demo Cruz"></div>		</div>

	<div class="site-branding" style="margin-bottom: 0px;">
	<div class="wrap">

		
		<div class="site-branding-text">
							<p class="site-title"><a href="/" rel="home">Demo Cruz</a></p>
			
							<p class="site-description">My WordPress Blog</p>
					</div><!-- .site-branding-text -->

		
	</div><!-- .wrap -->
</div><!-- .site-branding -->

</div><!-- .custom-header -->

		
	</header><!-- #masthead -->

	
	<div class="site-content-contain">
		<div id="content" class="site-content">

<style>
  #colophon {
    display: none;
  }

  #masthead {
    display: none;
  }

  .page:not(.home) #content {
    padding: 0 !important;
  }
</style>

<?php
    global $table_prefix, $wpdb;
  $form_path  = explode("/", trim($_SERVER['REQUEST_URI'], "/"));
  $sql        = "SELECT * FROM ".$table_prefix."catarina_forms WHERE form_path='".end($form_path)."'";
  $result     = $wpdb->get_results($sql, OBJECT);
  if(count($result) > 0) {
    $form_name = $result[0]->form_name;
    $form_path = $result[0]->form_path;
    $page_title =  $result[0]->page_title;
  } 

  if(isset($_POST['register_complete_name'])) {
    global $table_prefix, $wpdb;
    $name                 = $_POST['register_complete_name'];
    $email                = $_POST['register_complete_email'];
    $phone                = $_POST['register_complete_tel'];
    $zipcode              = $_POST['register_complete_cp'];
    $hasVisitSport        = $_POST['hasVisitSport'];
    $hasVisitAbroad       = $_POST['hasVisitAbroad'];
    $hasMeetCovidPeople   = $_POST['hasMeetCovidPeople'];

    $sql        = "SELECT * FROM ".$table_prefix."contact_data WHERE yourEmail='".$email."'";
    $result     = $wpdb->get_results($sql, OBJECT);
    if(count($result)>0) {
      $bad_email = "Please try again!";
    } else {
      $form_path  = explode("/", trim($_SERVER['REQUEST_URI'], "/"));
      $sql        = "SELECT * FROM ".$table_prefix."catarina_forms INNER JOIN ".$table_prefix."sta_category ON ".$table_prefix."sta_category.category_id=".$table_prefix."catarina_forms.category WHERE form_path='".end($form_path)."'";
      $result     = $wpdb->get_results($sql, OBJECT);
      
      if(count($result) > 0) {
          $form_name            = $result[0]->form_name;
          $form_path            = $result[0]->form_path;
          $page_title           = $result[0]->page_title;
          $category_name        = $result[0]->name;
          $category_identify    = $result[0]->identify;
          $category_description = $result[0]->description;
      } 
      
      $wpdb->insert($table_prefix.'contact_data', array(
          'isSportsCenter'  	=> $hasVisitSport,
          'isOtherCountry'   	=> $hasVisitAbroad,
          'iscovid'  			    => $hasMeetCovidPeople,
          'yourName'  		    => $name,
          'yourEmail'  		    => $email,
          'yourPhone' 		    => $phone,
          'yourZip'			      => $zipcode,
          'yourCategorias'	  => $category_name
          )
      );
      
      // original    $url = 'https://hook.integromat.com/4seluc7a7oggph5evl3hka5ucocwrh5v/?';
      $sql = "SELECT * FROM ".$table_prefix."integromat";
      $result = $wpdb->get_results($sql, OBJECT);
      $url = $result[0]->complete_form_link.'?';
      $url .= "name=".$name;
      $url .= "&email=".$email;
      $url .= "&phone=".$phone;
      $url .= "&zipcode=".$zipcode;
      $url .= "&category_name=".$category_name;
      $url .= "&category_identify=".$category_identify;
      $url .= "&category_description=".$category_description;

      
      if($hasVisitSport == 0) {
      $url .= "&hasVisitSport=No";
      } else {
      $url .= "&hasVisitSport=Si";
      }

      if($hasVisitAbroad == 0) {
      $url .= "&hasVisitAbroad=No";
      } else {
      $url .= "&hasVisitAbroad=Si";
      }

      if($hasMeetCovidPeople == 0) {
      $url .= "&hasMeetCovidPeople=No";
      } else {
      $url .= "&hasMeetCovidPeople=Si";
      }
      
      $url .= "&form_name=".$form_name;
      $url .= "&form_path=".$form_path;
      $response = wp_remote_get($url);

      if($response['response']['code'] == "200") {
          echo "<script>window.location.href='/registro-completo/?path=".$form_path."/'</script>";
      } else {
          $msg = "Please try again!";
      }
    }
  }
?>  
  <main id="site-content" role="main" style="height:100vh; overflow-y:auto; overflow-x:hidden">
    <div class="row gx-0 h-100">
      <div class="panel-left col col-12 col-sm-4 col-md-5 col-xxl-auto bg-primary">
        <div class="h-100 py-4 py-lg-5 d-flex flex-column">
          <img class="d-block m-auto pr-xl-5 logo" src="/wp-content/uploads/2020/11/escudo.png" />
          <div class="h-100 d-flex flex-column justify-content-center px-3 px-xl-5 mx-xxl-5">
            <section class="px-2 px-md-4 px-xl-5 text-white static-lateral">
                <?php
                  if(isset($page_title)) {
                    echo str_replace("\&quot;", "", $page_title);
                  }
                ?>
              <!-- <p class="mb-2">
                <strong>
                  #StaCatarina
                  <br>
                  <span style="color: #F2994A">
                    JUNTOS
                  </span>
                  <br>
                  Prevenir está en <br>
                  nuestras MANOS.
                </strong>
              </p>
              <p style="line-height: 10px;" class="mb-0"><small>
                  Ayúdanos a prevenir el contagio<br>
                  del Coronavirus <strong>COVID 19</strong>.
                </small></p> -->
            </section>
          </div>
          <div class="d-none d-sm-block">
            <p class="rights text-white text-center mb-0 px-3">
              <small>
                © Todos los Derechos Reservados 2020 Alcaldía Santa Catarina, Nuevo León
              </small>
            </p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="row h-100 align-items-center justify-content-center">
          <div class="col col-10 col-xl-7">
            <?php if(isset($response['response']['code']) && $response['response']['code'] == "200") {?>
            <h3 style="color: #4CAF50;"><?php echo $msg; ?></h3>
            <?php } else if(isset($response['response']['code']) && $response['response']['code'] != "200") {?>
            <h3 style="color: red;"><?php echo $msg; ?></h3>
            <?php }?>
            <h3></h3>
            <div id="cincomerca-stacatarina-forms">
              <form action="" method="POST" id='id_complete_form'>
                  <?php if(isset($bad_email)) { ?>
                    <div id="id_step_1" style="display: none;">
                  <?php } else { ?>
                    <div id="id_step_1">
                  <?php } ?>
                  
                    <div class="d-flex flex-column mb-4">
                      <div class="d-flex mb-3 mt-4 mt-lg-0 mb-lg-5">
                        <div class="dot mx-2 bg-primary" style="cursor: pointer;"></div>
                        <div class="dot mx-2 " style="cursor: pointer;"></div>
                        <div class="dot mx-2 " style="cursor: pointer;"></div>
                      </div>
                      <p style="font-size: 28px;">Bienvenido,</p>
                      <div class="mb-4">
                        <p for="hasVisitado" style="font-size: 16px;">¿Has visitado alguno de nuestros Centros Deportivos anteriormente?</p>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="hasVisitSport" id="hasVisitSport1" value="1" <?php if(isset($hasVisitSport) && $hasVisitSport==1) echo "checked" ?>>
                          <label class="form-check-label" for="inlineRadio1">Sí</label>
                        </div>
                        <div class="form-check form-check-inline" style="margin-left: 100px;">
                          <input class="form-check-input" type="radio" name="hasVisitSport" id="hasVisitSport2" value="0" <?php if(isset($hasVisitSport) && $hasVisitSport==0) echo "checked" ?>>
                          <label class="form-check-label" for="inlineRadio2">No</label>
                        </div>
                        <p style="font-size: 13px; color: red; display: none;" id="hasVisitSport_error">You have to choose one!</p>
                      </div>
                      <br>
                      <div>
                        <button class="btn btn-primary btn-xs-block" onclick="toStep(2)">Continuar 
                          <span>
                            <span>
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="injected-svg ml-3" data-src="https://cruzperezdesigns.co/wp-content/plugins/5merca-stacatarina//assets/images/icons/Arrow.svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: inherit; vertical-align: baseline;">
                                <path d="M11.6427 13.7124C11.5145 13.8254 11.3128 13.7359 11.3105 13.5651L11.2691 10.5106H0.2C0.0895434 10.5106 0 10.4211 0 10.3106V9.43391C0 9.32345 0.0895431 9.23391 0.2 9.23391H11.2691L11.3103 6.41688C11.3127 6.24906 11.5083 6.15871 11.6377 6.26566L15.8194 9.72299C15.9142 9.80135 15.9165 9.94587 15.8242 10.0272L11.6427 13.7124Z" fill="white"></path>
                              </svg>
                            </span>
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div id="id_step_2" style="display: none;">
                    <div class="d-flex flex-column mb-4">
                      <div class="d-flex mb-3 mt-4 mt-lg-0 mb-lg-5">
                        <div class="dot mx-2 bg-primary" style="cursor: pointer;"></div>
                        <div class="dot mx-2 bg-primary" style="cursor: pointer;"></div>
                        <div class="dot mx-2 " style="cursor: pointer;"></div>
                      </div>
                      <p style="font-size: 28px;">Ayúdanos respondiendo...</p>
                      <div class="mb-4">
                        <p style="font-size: 16px;">¿Has viajado fuera del país durante los últimos 30 días?</p>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="hasVisitAbroad" id="hasVisitAbroad1" value="1" <?php if(isset($hasVisitAbroad) && $hasVisitAbroad==1) echo "checked" ?>>
                          <label class="form-check-label" for="inlineRadio1">Sí</label>
                        </div>
                        <div class="form-check form-check-inline" style="margin-left: 100px;">
                          <input class="form-check-input" type="radio" name="hasVisitAbroad" id="hasVisitAbroad2" value="0" <?php if(isset($hasVisitAbroad) && $hasVisitAbroad==0) echo "checked" ?>>
                          <label class="form-check-label" for="inlineRadio2">No</label>
                        </div>
                        <p style="font-size: 13px; color: red; display: none;" id="hasVisitAbroad_error">You have to choose one!</p>
                      </div>
                      <div class="mb-4">
                        <p style="font-size: 16px;">¿Has tenido contacto con personas diagnosticadas con COVID 19?</p>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="hasMeetCovidPeople" id="hasMeetCovidPeople1" value="1" <?php if(isset($hasMeetCovidPeople) && $hasMeetCovidPeople==1) echo "checked" ?>>
                          <label class="form-check-label" for="inlineRadio3">Sí</label>
                        </div>
                        <div class="form-check form-check-inline" style="margin-left: 100px;">
                          <input class="form-check-input" type="radio" name="hasMeetCovidPeople" id="hasMeetCovidPeople2" value="0" <?php if(isset($hasMeetCovidPeople) && $hasMeetCovidPeople==0) echo "checked" ?>>
                          <label class="form-check-label" for="inlineRadio4">No</label>
                        </div>
                        <p style="font-size: 13px; color: red; display: none;" id="hasMeetCovidPeople_error">You have to choose one!</p>
                      </div>
                      <br>
                      <div>
                        <button class="btn btn-primary btn-xs-block" onclick="toStep(3)">Continuar 
                          <span>
                            <span>
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="injected-svg ml-3" data-src="https://cruzperezdesigns.co/wp-content/plugins/5merca-stacatarina//assets/images/icons/Arrow.svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: inherit; vertical-align: baseline;">
                                <path d="M11.6427 13.7124C11.5145 13.8254 11.3128 13.7359 11.3105 13.5651L11.2691 10.5106H0.2C0.0895434 10.5106 0 10.4211 0 10.3106V9.43391C0 9.32345 0.0895431 9.23391 0.2 9.23391H11.2691L11.3103 6.41688C11.3127 6.24906 11.5083 6.15871 11.6377 6.26566L15.8194 9.72299C15.9142 9.80135 15.9165 9.94587 15.8242 10.0272L11.6427 13.7124Z" fill="white"></path>
                              </svg>
                            </span>
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                  <?php if(isset($bad_email)) { ?>
                    <div id="id_step_3">
                  <?php } else { ?>
                    <div id="id_step_3" style="display: none;">
                  <?php } ?>
                  
                    <div class="d-flex flex-column mb-4">
                        <!-- <div class="top-float order-last">
                            <small class="mr-4 text-muted mb-2 d-inline-block">¿Ya estás registrado?</small>
                            <button class="btn btn-outline-primary btn-xs-block">Ingresa Aquí</button>
                        </div> -->
                        <p style="font-size: 28px;">Bienvenido,</p>
                        <p class="display-6 mb-4 mb-lg-5">Ingresa tus siguientes datos.</p>
                        <div class="mb-4">
                            <label for="name" class="form-label" id="name_label">Nombre</label>
                            <input type="text" class="form-control" id="name" name="register_complete_name" value="<?php if(isset($name)) echo $name; ?>" placeholder="Escribe tu nombre completo" required="">
                            <label for="name" class="form-label label-warn" id="name_warn">Ingresa tu nombre!</label>
                        </div>
                        <div class="mb-4">
                            <label for="email" class="form-label" id="email_label">Correo electrónico</label>
                            <input type="email" class="form-control" id="email" name="register_complete_email" value="<?php if(isset($email)) echo $email; ?>" placeholder="Escribe tu correo electrónico" required="">
                            <label for="name" class="form-label label-warn" id="email_warn">Ingresa un correo electrónico correcto!</label>
                            <?php if(isset($bad_email)) { ?>
                              <label for="name" class="form-label label-warn" id="email_existing_warn" style="display: block !important;">El correo ya esta registrado.!</label>
                            <?php } ?>
                        </div>
                        <div class="mb-4 row">
                            <div class="col col-12 col-sm-7 col-lg-8 mb-4">
                                <label for="tel" class="form-label" id="tel_label">Teléfono de contacto</label>
                                <input type="number" class="form-control" id="tel" name="register_complete_tel" value="<?php if(isset($phone)) echo $phone; ?>" onKeyPress="if(this.value.length==10) return false;" required="" placeholder="Escribe tu número de teléfono fijo o celular">
                                <label for="name" class="form-label label-warn" id="tel_warn">Ingresa un número telefónico!</label>
                            </div>
                            <div class="col col-12 col-sm-5 col-lg-4">
                                <label for="cp" class="form-label" id="cp_label">Código postal</label>
                                <input type="number" class="form-control" required="" name="register_complete_cp" value="<?php if(isset($zipcode)) echo $zipcode; ?>" onKeyPress="if(this.value.length==5) return false;" id="cp" placeholder="C.P.">
                                <label for="name" class="form-label label-warn" id="cp_warn">Ingresa tu código postal!</label>
                            </div>
                        </div><br>
                        <div>
                            <button class="btn btn-primary btn-xs-block" type="button" onclick="validateRegister()" id="btn_submit">Registrarme 
                                <span>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" class="injected-svg ml-3" data-src="https://cruzperezdesigns.co/wp-content/plugins/5merca-stacatarina//assets/images/icons/Arrow.svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: inherit; vertical-align: baseline;">
                                            <path d="M11.6427 13.7124C11.5145 13.8254 11.3128 13.7359 11.3105 13.5651L11.2691 10.5106H0.2C0.0895434 10.5106 0 10.4211 0 10.3106V9.43391C0 9.32345 0.0895431 9.23391 0.2 9.23391H11.2691L11.3103 6.41688C11.3127 6.24906 11.5083 6.15871 11.6377 6.26566L15.8194 9.72299C15.9142 9.80135 15.9165 9.94587 15.8242 10.0272L11.6427 13.7124Z" fill="white"></path>
                                        </svg>
                                    </span>
                                </span>
                            </button>
                        </div><br>
                        <div></div>
                    </div>
                  </div>
              </form>
            </div>
          </div>
        </div>
        <div class="d-block d-sm-none">
          <p class="rights text-muted text-center mb-2 px-3">
            <small>
              © Todos los Derechos Reservados Alcaldía Santa Catarina, Nuevo León
            </small>
          </p>
        </div>
      </div>
    </div>
  </main>

  <script>
    function validateRegister() {
        let valid = 1;
        if (document.getElementById("name")) {
            if (document.getElementById("name").value == "")
            {
                document.getElementById("name").classList.add("form-input-warn");
                document.getElementById("name_warn").style.display="block";
                valid = 0;
            } else {
                document.getElementById("name").classList.remove("form-input-warn");
                document.getElementById("name_warn").style.display="none";
            }
        }
        
        if (document.getElementById("email").value == "")
        {
            document.getElementById("email").classList.add("form-input-warn");
            document.getElementById("email_warn").style.display="block";
            valid = 0;
        } else {
            document.getElementById("email").classList.remove("form-input-warn");
            document.getElementById("email_warn").style.display="none";
        }
        let email = document.getElementById("email").value;
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(!re.test(email)) {
            document.getElementById("email").classList.add("form-input-warn");
            document.getElementById("email_warn").style.display="block";
            valid = 0;
        } else {
            document.getElementById("email").classList.remove("form-input-warn");
            document.getElementById("email_warn").style.display="none";
        }

        if (document.getElementById("tel")) {
            if (document.getElementById("tel").value == "")
            {
                document.getElementById("tel").classList.add("form-input-warn");
                document.getElementById("tel_warn").style.display="block";
                valid = 0;
            } else {
                document.getElementById("tel").classList.remove("form-input-warn");
                document.getElementById("tel_warn").style.display="none";
            }
        }
        
        if (document.getElementById("cp")){
            if (document.getElementById("cp").value == "")
            {
                document.getElementById("cp").classList.add("form-input-warn");
                document.getElementById("cp_warn").style.display="block";
                valid = 0;
            } else {
                document.getElementById("cp").classList.remove("form-input-warn");
                document.getElementById("cp_warn").style.display="none";
            }
        }

        if(valid != 0){
            document.getElementById("id_complete_form").submit();					
        }
    }


    function toStep(i) {
      var before_index = i-1;
      if(i==2) {
        var ele1= document.getElementById("hasVisitSport1");
        var ele2= document.getElementById("hasVisitSport2");
        if(ele1.checked==false && ele2.checked==false) {
          document.getElementById("hasVisitSport_error").style.display = "block";
        } else {
          document.getElementById("hasVisitSport_error").style.display = "none";
          document.getElementById("id_step_"+before_index).style.display = "none";
          document.getElementById("id_step_"+i).style.display = "block";
        }
      }
      if(i==3) {
        var ele1= document.getElementById("hasVisitAbroad1");
        var ele2= document.getElementById("hasVisitAbroad2");
        var ele3= document.getElementById("hasMeetCovidPeople1");
        var ele4= document.getElementById("hasMeetCovidPeople2");
        var validate = 1;
        if(ele1.checked==false && ele2.checked==false) {
          var validate = 0;
          document.getElementById("hasVisitAbroad_error").style.display = "block";
        } else {
          document.getElementById("hasVisitAbroad_error").style.display = "none";
        }
        
        if(ele3.checked==false && ele4.checked==false) {
          var validate = 0;
          document.getElementById("hasMeetCovidPeople_error").style.display = "block";
        } else {
          document.getElementById("hasMeetCovidPeople_error").style.display = "none";
        }
        
        if(validate==1) {
          document.getElementById("id_step_"+before_index).style.display = "none";
          document.getElementById("id_step_"+i).style.display = "block";
        }
      }
    }
    
    function validateEmail() {
    	var email = document.getElementById("email").value;
    	var myformdata = { 
    		action: 'ajaxValidateEmail', 
    		yourEmail: email
    	};
    
    	var validate = 1;
    	jQuery.ajax({
    	  type:"POST",
    	  url: "/wp-content/plugins/sta.catarina/sta-catarina.php",
    	  data: myformdata,
    	  success:function(data){
          console.log(data);
    		if(data==200) {
          console.log("success");
          document.getElementById("email").classList.remove("form-input-warn");
          document.getElementById("email_existing_warn").style.display="none";
          document.getElementById("btn_submit").disabled = false;
    		} else {
          console.log("failed");
    			document.getElementById("email").classList.add("form-input-warn");
          document.getElementById("email_existing_warn").style.display="block";
          document.getElementById("btn_submit").disabled = true;
    		}
    	  },
    	  error: function(errorThrown){
    		  alert(errorThrown);
    	  } 
    	});	
    }
  </script>
<?php
	get_footer();