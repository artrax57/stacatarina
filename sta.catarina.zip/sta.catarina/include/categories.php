<?php
    if(isset($_POST['bulk_category_action_delete'])) {
        foreach($_POST['deletableCategories'] as $check) {
            global $table_prefix, $wpdb;
            $wpdb->query($wpdb->prepare("DELETE FROM ".$table_prefix."sta_category WHERE category_id = %d", $check));
        }   
    }

    if(isset($_POST['category_name']) && $_POST['category_name']!="") {
        $category_name          = $_POST['category_name'];
        $category_identify      = $_POST['category_identify'];
        $category_description   = $_POST['category_description'];

        $sql = "SELECT * FROM ".$table_prefix."sta_category WHERE name='".$category_name."'";
        $result = $wpdb->get_results($sql, OBJECT);

        if(count($result)>0) {
            $error = "Form Name or Form Url is already existed!";
        } else {
            $wpdb->insert($table_prefix.'sta_category', array(
                'name'  	    => $category_name,
                'identify'   	=> $category_identify,
                'description'  	=> $category_description
                    )
            );
        }        
    }

    function categories() {
        ?>
        <h2>Categories</h2>
        <div style="width: 100%; display: flex;">
            <div style="width: 40%;">
                <form action="" method="POST">
                    <label for="category_name">Nombre</label><br>
                    <input name="category_name" type="text" id="category_name" value="" aria-required="true" autocapitalize="none" autocorrect="off" style="width: 100%;"><br>
                    <label for="category_identify">Identify</label><br>
                    <input name="category_identify" type="text" id="category_identify" value="" aria-required="true" autocapitalize="none" autocorrect="off" style="width: 100%;"><br>
                    <label for="category_description">Description</label><br>
                    <textarea name="category_description" id="" cols="30" rows="10" style="width: 100%;"></textarea><br>
                    <input type="submit" name="submit" style="background-color: #0071a1; border: none; color: white; padding-right: 20px; padding-left: 20px; padding-top: 10px; padding-bottom: 10px;" value="Submit">
                </form>
            </div>
            <div style="width: 60%; padding-left: 20px; padding-right: 20px;">
                <?php
                    global $table_prefix, $wpdb;
                    $paged = isset($_GET['paged']) ? $_GET['paged'] : 1;
                    $sort['name'] = isset($_GET['sort']) ? $_GET['sort'] : 'ID';
                    $sort['order'] = isset($_GET['order']) ? $_GET['order'] : 'DESC';
                    $sort_by = ' ORDER BY ' . $sort['name'] . ' '. $sort['order'];
                    $link = 'admin.php?page=sta-catarina-menu';
        
                    $sql = "SELECT * FROM ".$table_prefix."sta_category";
                    $rows = $wpdb->get_results($sql, OBJECT);
                    $rows_per_page = 10;
        
                    // add pagination arguments from WordPress
                    $pagination_args = array(
                        'base' => add_query_arg('paged','%#%'),
                        'format' => '',
                        'total' => ceil(sizeof($rows)/$rows_per_page),
                        'current' => $paged,
                        'show_all' => false,
                        'type' => 'plain',
                    );
        
                    $start = ($paged - 1) * $rows_per_page;
                    $end_initial = $start + $rows_per_page;
                    $end = (sizeof($rows) < $end_initial) ? sizeof($rows) : $end_initial;
                ?>
                <form action="" method="POST">
                    <div class="tablenav top">
                        <div class="alignleft actions bulkactions">
                            <label for="bulk-action-selector-top" class="screen-reader-text">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Select batch action</font>
                                </font>
                            </label>
                            <select name="bulk_action" id="bulk-action-selector-top">
                                <option value="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Batch Actions</font></font></option>
                                <option value="delete"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Delete</font></font></option>
                            </select>
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">
                                    <input type="submit" id="doaction" class="button action" name="bulk_category_action_delete" value="Apply">
                                </font>
                            </font>
                        </div>
                        <div class="alignleft actions">
                            <label class="screen-reader-text" for="new_role">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Change profile to ...</font>
                                </font>
                            </label>
                            <select name="new_role" id="new_role">
                                <option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Change profile to ...</font></font></option>
                                <option value="css_js_designer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Web Designer</font></font></option>
                                <option value="subscriber"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Subscriber</font></font></option>
                                <option value="contributor"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Collaborator</font></font></option>
                                <option value="author"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Author</font></font></option>
                                <option value="editor"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Editor</font></font></option>
                                <option value="administrator"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Administrator</font></font></option>		
                            </select>
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">
                                    <input type="submit" name="changeit" id="changeit" class="button" value="Change">
                                </font>
                            </font>		
                        </div>
                        <div class="tablenav-pages one-page">
                            <span class="displaying-num">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;"><?php echo count($rows); ?> item</font>
                                </font>
                            </span>
                            <span class="pagination-links">
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">«</span>
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>
                                <span class="paging-input">
                                    <label for="current-page-selector" class="screen-reader-text">Página actual</label>
                                    <input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging">
                                    <span class="tablenav-paging-text"> de <span class="total-pages">1</span></span>
                                </span>
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">»</span>
                            </span>
                        </div>
                        <br class="clear">
                    </div>
                    <table id="user-sent-mail" class="wp-list-table widefat fixed users" style="width: 100%;">
                        <thead>
                            <tr class="manage-column">
                                <th style="width: 30px;">
                                    <input type="checkbox" name="" id="selectAllup" class="checkAll" style="margin-left: 0;">
                                </th>
                                <th class="col-subject">
                                    Nombre
                                </th>
                                <th class="col-body">
                                    Description
                                </th>
                                <th class="col-created">
                                    Identificador
                                </th>
                                <th class="col-created">
                                    Cantidad
                                </th>
                            </tr>
                        </thead>
                        <?php
                        if (count($rows) > 0) {
                            // prepare link for pagination
                            $link .= '&paged=' . $paged;
            
                            $order = $sort['order'] == "ASC" ? "DESC" : "ASC";
                        ?>
                    
                        <tbody>
                            <?php
                                // add rows
                                for ($index = $start; $index < $end;  ++$index) {
                                    $row = $rows[$index];
        
                                    $class_row = ($index % 2 == 1 ) ? ' class="alternate"' : '';
                            ?>
                            <tr <?php echo $class_row; ?>>
                                <td style="width: 30px;"><input type="checkbox" name="deletableCategories[]" value="<?php echo $row->category_id;?>" class="checkboxes" name=""></td>
                                <td> <a><?php echo $row->name; ?></a></td>
                                <td> <a><?php echo $row->description; ?></a></td>
                                <td> <a><?php echo $row->identify; ?></a></td>
                                <td> <a>0</a></td>
                            </tr>
                            <? } ?>
                        </tbody>
                        <tr class="manage-column">
                            <th style="width: 30px; margin-left: 0; border-top: 1px solid #ccd0d4;">
                                <input type="checkbox" name="bulk_forms" value="<?php echo $row->category_id; ?>" id="selectAlldown" class="checkAll" style="margin-left: 0;">
                            </th>
                            <th class="col-subject" style="border-top: 1px solid #ccd0d4;">
                                Nombre
                            </th>
                            <th class="col-body" style="border-top: 1px solid #ccd0d4;">
                                Description
                            </th>
                            <th class="col-created" style="border-top: 1px solid #ccd0d4;">
                                Identificador
                            </th>
                            <th class="col-created" style="border-top: 1px solid #ccd0d4;">
                                Cantidad
                            </th>
                        </tr>
                    
                        <?php
                            //add pagination links from WordPress
                            echo paginate_links($pagination_args);
            
                        } else {
                            ?>
                                <tr>
                                    <td colspan="6">No records found, try again please</td>
                                </tr>
                        <?php
                        }
                        ?>
                    </table>
                </form>
                    
            </div>
        </div>
        <?php
    }
?>