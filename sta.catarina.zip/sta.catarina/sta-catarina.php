<?php
    /**
     * Plugin Name: Formularios Sta.Catarina
     * Plugin URI: https://godservice.co/
     * Description: This plugin enable the option to create membership
     * accounts with the options to buy or rent products from woo commerce
     * and also the system awards you with game coins that you can use to
     * make payments on the site.
     * Version: 0.9
     * Author: Manuel Salazar and godservice.co
     * Author URI: http://www.developerwebsite.com
     */
    require_once plugin_dir_path(__FILE__) . 'include/categories.php'; 
    require_once plugin_dir_path(__FILE__) . 'include/integromat.php';
    add_action( 'admin_menu', 'main' );
    add_action("template_redirect", 'my_theme_redirect');

    function main() {
        $plugin_page = add_menu_page(
            'Sta. Catarina', // Title of the page
            'Formularios Sta.Catarina', // Text to show on the menu link
            'manage_options', // Capability requirement to see the link
            'sta-catarina-menu',
            'main_page', // The 'slug' - file to display when clicking the link
            '',
            200
        );

        add_action( 'load-' . $plugin_page, 'add_js_script' );
        $rental_list = add_submenu_page( 'sta-catarina-menu', 'Categories'        , 'Categories'         , 'manage_options', 'categories', 'categories');
        add_action( 'load-' . $rental_list, 'add_js_script' );
        add_action("template_redirect", 'my_theme_redirect');
        $integromat = add_submenu_page( 'sta-catarina-menu', 'Integromat Webhooks'        , 'Integromat Webhooks'         , 'manage_options', 'integromat', 'integromat');
    }       
    
    if(isset($_POST['bulk_action_delete'])) {
        if($_POST['bulk_action'] == "delete") {
            foreach($_POST['forms'] as $check) {
                global $table_prefix, $wpdb;
                $wpdb->query($wpdb->prepare("DELETE FROM ".$table_prefix."catarina_forms WHERE form_id = %d", $check));
            }
        }
    }    
    
    if(isset($_POST['action']) && $_POST['action']=="ajaxValidateEmail") {
        echo "500";
    }

    function main_page() {
        global $table_prefix, $wpdb;
    
        $wp_track_table = $table_prefix . "catarina_forms";
    
        #Check to see if the table exists already, if not, then create it
    
        if($wpdb->get_var( "show tables like '$wp_track_table'" ) != $wp_track_table) 
        {
            $sql = "CREATE TABLE `".$wp_track_table."` ( ";
            $sql .= "    `form_id` int(11) NOT NULL AUTO_INCREMENT, ";
            $sql .= "    `form_type` int(11) DEFAULT NULL COMMENT '0: simple, 1: complete', ";
            $sql .= "    `form_name` varchar(225) DEFAULT NULL, ";
            $sql .= "   `form_path` varchar(225) DEFAULT NULL, ";
            $sql .= "    `db_name` varchar(225) DEFAULT NULL,"; 
            $sql .= "    `db_user` varchar(225) DEFAULT NULL,"; 
            $sql .= "    `db_contrary` varchar(225) DEFAULT NULL, ";
            $sql .= "    `created_at` datetime DEFAULT NULL, ";
            $sql .= "    `active` int(11) DEFAULT NULL, ";
            $sql .= "    `category` int(11) DEFAULT NULL, ";
            $sql .= "    `page_title` text DEFAULT NULL, PRIMARY KEY (`form_id`)"; 
            $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1;";
            $wpdb->query($wpdb->prepare($sql));
        }

        $wp_track_table = $table_prefix . "sta_category";
    
        if($wpdb->get_var( "show tables like '$wp_track_table'" ) != $wp_track_table) 
        {
            $sql = "CREATE TABLE `".$wp_track_table."` ( ";
            $sql .= "    `category_id` int(11) NOT NULL AUTO_INCREMENT, ";
            $sql .= "    `name` varchar(225) DEFAULT NULL, ";
            $sql .= "    `identify` varchar(225) DEFAULT NULL,"; 
            $sql .= "    `description` text DEFAULT NULL, PRIMARY KEY (`category_id`)"; 
            $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1;";
            
            $wpdb->query($wpdb->prepare($sql));
        }

        $wp_track_table = $table_prefix . "integromat";

        if($wpdb->get_var( "show tables like '$wp_track_table'" ) != $wp_track_table) 
        {
            $sql = "CREATE TABLE `".$wp_track_table."` ( ";
            $sql .= "    `integromat_id` int(11) NOT NULL AUTO_INCREMENT, ";
            $sql .= "    `simple_form_link` varchar(225) DEFAULT NULL, ";
            $sql .= "    `complete_form_link` varchar(225) DEFAULT NULL, PRIMARY KEY (`integromat_id`)";
            $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1;";
            $wpdb->query($wpdb->prepare($sql));
        }

        $wp_track_table = $table_prefix . "contact_data";

        if($wpdb->get_var( "show tables like '$wp_track_table'" ) != $wp_track_table) 
        {
            $sql = "CREATE TABLE `".$wp_track_table."` ( ";
            $sql .= "    `id` int(11) NOT NULL AUTO_INCREMENT,";
            $sql .= "    `isSportsCenter` varchar(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `isOtherCountry` varchar(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `iscovid` varchar(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `yourName` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `yourEmail` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `yourPhone` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `yourZip` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,";
            $sql .= "    `yourCategorias` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL, PRIMARY KEY (`id`)";
            $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;";
            $wpdb->query($wpdb->prepare($sql));
        }

        if(isset($_POST['form_type'])) {
            global $table_prefix, $wpdb;
            $form_type 		= $_POST['form_type'];
            $form_name 		= $_POST['form_name'];
            $form_path 		= $_POST['form_path'];
            $db_name 		= $_POST['db_name'];
            $db_user 		= $_POST['db_user'];
            $db_contrary 	= $_POST['db_contrary'];
            $form_subject   = $_POST['form_subject'];
            $page_title     = $_POST['page_title'];
            $created_at 	= date('Y-m-d');
            
            $sql = "SELECT * FROM ".$table_prefix."catarina_forms WHERE form_name='".$form_name."' OR form_path='".$form_path."'";
            $result = $wpdb->get_results($sql, OBJECT);

            if(count($result)>0) {
                $error = "Nombre de la url o del formulario ya existen. Por favor, vuelva a crear el formulario con un nombre diferente.";
            } else {
                $wpdb->insert($table_prefix.'catarina_forms', array(
                    'form_type'  	=> $form_type,
                    'form_name'   	=> $form_name,
                    'form_path'  	=> $form_path,
                    'db_name'  		=> $db_name,
                    'db_user'  		=> $db_user,
                    'db_contrary' 	=> $db_contrary,
                    'created_at'	=> $created_at,
                    'category'	    => $form_subject,
                    'page_title'    => $page_title,
                    'active'        => 1
                    )
                );

                $post_details = array(
                    'post_title'    => $form_path,
                    'post_content'  => '',
                    'post_status'   => 'publish',
                    'post_author'   => 1,
                    'post_type' => 'page'
                );

                $page_id = wp_insert_post( $post_details );; 
                if($form_type == 0) {
                    update_post_meta( $page_id, 'page-register-simple.php' );
                } else {
                    update_post_meta( $page_id, 'page-register-complete.php' );
                }
            }
        }
        ?>
            <div class="wrap">
                <h1 class="wp-heading-inline"> Formularios Sta. Catarina</h1>
                <a onclick="document.getElementById('id01').style.display='block'" class="page-title-action">Generar nueva replica</a>
                <hr class="wp-header-end">
            </div>
        <?php

            global $table_prefix, $wpdb;
            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1;
            $sort['name'] = isset($_GET['sort']) ? $_GET['sort'] : 'ID';
            $sort['order'] = isset($_GET['order']) ? $_GET['order'] : 'DESC';
            $sort_by = ' ORDER BY ' . $sort['name'] . ' '. $sort['order'];
            $link = 'admin.php?page=sta-catarina-menu';
            
            if(isset($error)) {
                ?>
                    <h3 style="color: red; margin-top: 50px; margin-bottom: 50px;"><?php echo $error; ?></h3>
                <?php
            }
            ?>
            
            <nav class="nav-tab-wrapper woo-nav-tab-wrapper">
                <a class="nav-tab nav-tab-active" onclick="openCity('id_membership_type', this)">Formularios Generados</a>
                <a class="nav-tab" onclick="openCity('id_referal_plan', this)">Formularios</a>
            </nav>
            
            <div id="id_membership_type" class="w3-container city">
                <form action="<?php echo $link; ?>" method="get" style="display: none;">
                    <input type="hidden" name="page" value="user_list">
                    <input type="hidden" name="sort" value="<?php echo $sort['name']; ?>">
                    <input type="hidden" name="order" value="<?php echo $sort['order']; ?>">
                    <input type="hidden" name="paged" value="<?php echo $paged; ?>">
                    <input type="submit" value="Send">
                </form>
                <form action="" method="POST">
                    <div class="tablenav top">
                        <div class="alignleft actions bulkactions">
                            <label for="bulk-action-selector-top" class="screen-reader-text">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Select batch action</font>
                                </font>
                            </label>
                            <select name="bulk_action" id="bulk-action-selector-top">
                                <option value="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Batch Actions</font></font></option>
                                <option value="delete"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Delete</font></font></option>
                            </select>
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">
                                    <input type="submit" id="doaction" class="button action" name="bulk_action_delete" value="Apply">
                                </font>
                            </font>
                        </div>
                        <div class="alignleft actions">
                            <label class="screen-reader-text" for="new_role">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Change profile to ...</font>
                                </font>
                            </label>
                            <select name="new_role" id="new_role">
                                <option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Change profile to ...</font></font></option>
                                <option value="css_js_designer"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Web Designer</font></font></option>
                                <option value="subscriber"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Subscriber</font></font></option>
                                <option value="contributor"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Collaborator</font></font></option>
                                <option value="author"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Author</font></font></option>
                                <option value="editor"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Editor</font></font></option>
                                <option value="administrator"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Administrator</font></font></option>		
                            </select>
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">
                                    <input type="submit" name="changeit" id="changeit" class="button" value="Change">
                                </font>
                            </font>		
                        </div>
                        <div class="tablenav-pages one-page">
                            <span class="displaying-num">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">1 item</font>
                                </font>
                            </span>
                            <span class="pagination-links">
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">«</span>
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>
                                <span class="paging-input">
                                    <label for="current-page-selector" class="screen-reader-text">Página actual</label>
                                    <input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging">
                                    <span class="tablenav-paging-text"> de <span class="total-pages">1</span></span>
                                </span>
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>
                                <span class="tablenav-pages-navspan button disabled" aria-hidden="true">»</span>
                            </span>
                        </div>
                        <br class="clear">
                    </div>
                
                    <?php
                        $sql = 'SELECT * FROM '.$table_prefix.'catarina_forms LEFT JOIN '.$table_prefix.'sta_category ON '.$table_prefix.'sta_category.category_id='.$table_prefix.'catarina_forms.category';
                        $rows = $wpdb->get_results($sql);
                        $rows_per_page = 10;

                        // add pagination arguments from WordPress
                        $pagination_args = array(
                            'base' => add_query_arg('paged','%#%'),
                            'format' => '',
                            'total' => ceil(sizeof($rows)/$rows_per_page),
                            'current' => $paged,
                            'show_all' => false,
                            'type' => 'plain',
                        );

                        $start = ($paged - 1) * $rows_per_page;
                        $end_initial = $start + $rows_per_page;
                        $end = (sizeof($rows) < $end_initial) ? sizeof($rows) : $end_initial;
                    ?>
                    <table id="user-sent-mail" class="wp-list-table widefat fixed users">
                        <thead>
                            <tr class="manage-column">
                                <th style="width: 30px;">
                                    <input type="checkbox" name="" id="selectAllup" class="checkAll" style="margin-left: 0;">
                                </th>
                                <th class="col-from">
                                    <a href="">
                                        Titulo
                                    </a>
                                </th>
                                <th class="col-subject">
                                    Ruta/Subdirectorio
                                </th>
                                <th class="col-body">
                                    Formulario
                                </th>
                                <th class="col-body">
                                    Subject
                                </th>
                            </tr>
                        </thead>
                        <?php
                        if (count($rows) > 0) {
                            // prepare link for pagination
                            $link .= '&paged=' . $paged;

                            $order = $sort['order'] == "ASC" ? "DESC" : "ASC";
                        ?>
                
                        <tbody>
                            <?php
                                // add rows
                                for ($index = $start; $index < $end;  ++$index) {
                                    $row = $rows[$index];
                                    $class_row = ($index % 2 == 1 ) ? ' class="alternate"' : '';
                            ?>
                            <tr <?php echo $class_row; ?>>
                                <td style="width: 30px;"><input type="checkbox" name="forms[]" value="<?php echo $row->form_id;?>" class="checkboxes" name=""></td>
                                <td> 
                                    <a>
                                    <?php 
                                        if($row->form_type == 0)
                                            echo "Simple Form";
                                        else 
                                            echo "Complete Form"; 
                                    ?>
                                    </a>
                                </td>
                                <td> <a><?php echo $row->form_name; ?></a></td>
                                <td> <a><?php echo $row->form_path; ?></a></td>
                                <td> <a><?php echo $row->name; ?></a></td>
                            </tr>
                            <? } ?>
                        </tbody>
                        <tr class="manage-column">
                            <th style="width: 30px; margin-left: 0; border-top: 1px solid #ccd0d4;">
                                <input type="checkbox" name="bulk_forms" value="<?php echo $row->id; ?>" id="selectAlldown" class="checkAll" style="margin-left: 0;">
                            </th>
                            <th class="col-from" style="border-top: 1px solid #ccd0d4;">
                                <a href="">
                                    Titulo
                                </a>
                            </th>
                            <th class="col-subject" style="border-top: 1px solid #ccd0d4;">
                                Ruta/Subdirectorio
                            </th>
                            <th class="col-body" style="border-top: 1px solid #ccd0d4;">
                                Formulario
                            </th>
                            <th class="col-body">
                                Subject
                            </th>
                        </tr>
                
                        <?php }?>
                    </table>
                </form>
            </div>  
            
            <div id="id_referal_plan" class="w3-container city" style="text-align: center; display: none;">  
                <img src="/wp-content/plugins/file-manager-advanced/application/assets/icon/fma.png" style="margin-top: 60px; width: 60px;"> 
                <h1>Replica tu primer formulario</h1>
                <div>
                    <p>
                        Replica tus formularios simples o compuestos las veces que to desees,<br> solo anade la ruta con el 
                        nombre que deseas tenga el formulario y listo.
                    </p>
                    <button class="w3-button w3-indigo" onclick="document.getElementById('id01').style.display='block'">CREA NUEVA REPLICA</button>
                </div>
            </div>
            <div id="id01" class="w3-modal">
                <div class="w3-modal-content">
                    <div class="w3-container" style="padding-left: 25%; padding-right: 25%; padding-bottom: 50px; padding-top: 100px; background-color: #f2f3f5;">
                        <div class="w3-button w3-display-topright" style="width: 100%; box-shadow: 0px 0px 8px 2px rgba(0,0,0,0.19); background-color: #fff;">
                            <table style="width: 100%;">
                                <tr>
                                    <td style="width: 35px;">
                                        <div style="border-radius: 50%; background-color: #042aa5; width: 25px; height: 25px;"></div>
                                    </td>
                                    <td style="text-align: left;">
                                        <b>NUEVA PLANTILLA</b>
                                    </td>
                                    <td>
                                        <span onclick="document.getElementById('id01').style.display='none'" style="float: right;">&times;</span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <form class="w3-container w3-card-4" action="" method="POST" style="text-align: left; padding: 40px; background-color: #fff;" id="id_form_submit">
                            <h2 class="w3-text-black">Elige el tipo de formulario</h2>
                            <div id="id_main_form_info">    
                                <p>      
                                    <label class="w3-text-black"><b>Elige el tipo de formulario que quieres replicar</b></label>
                                    <select name="form_type" class="w3-input w3-border" style="max-width: 100%;" id="id_form_type">
                                        <option value="0">Simple Form</option>
                                        <option value="1">Complete Form</option>
                                    </select>
                                </p>
                                <p>      
                                    <label class="w3-text-black"><b>Nombre del formulario</b></label>
                                    <input class="w3-input w3-border" name="form_name" type="text">
                                </p>
                                <p>      
                                    <label class="w3-text-black"><b>Ruta del formulario</b></label>
                                    <table style="width: 100%;">
                                    <tr>
                                        <td>/</td>
                                        <td><input class="w3-input w3-border" name="form_path" type="text"></td>
                                    </tr>
                                    </table>
                                    
                                </p>
                                <?php
                                    global $table_prefix, $wpdb;
                                    $sql = "SELECT * FROM ".$table_prefix."sta_category";
                                    $result = $wpdb->get_results($sql, OBJECT);
                                ?>
                                <p>      
                                    <label class="w3-text-black"><b>Indique el concepto del formulario</b></label>
                                    <select name="form_subject" class="w3-input w3-border" style="max-width: 100%;" id="id_form_subject">
                                        <option value="">Seleccione concepto del formulario</option>
                                        <?php for($i=0; $i<count($result); $i++) { ?>
                                            <option value="<?php echo $result[$i]->category_id?>"><?php echo $result[$i]->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <span style="color: red; display: none;" id="subject_warning">Seleccione una categoría.</span>

                                </p>

                                <p style="display: none;">      
                                    <label class="w3-text-black"><b>Nombre de la Base de Datos</b></label>
                                    <input class="w3-input w3-border" name="db_name" type="text">
                                </p>
                                <p style="display: none;">      
                                    <label class="w3-text-black"><b>Usuario de la Base de Datos</b></label>
                                    <input class="w3-input w3-border" name="db_user" type="text">
                                </p>
                                <p style="display: none;">      
                                    <label class="w3-text-black"><b>Contraseria de la Base de Datos</b></label>
                                    <input class="w3-input w3-border" name="db_contrary" type="text">
                                </p>
                                <p>      
                                    <input class="w3-btn w3-black" type="button" onclick="toNextStep()" style="width: 100%; background-color: #042aa5 !important; margin-top: 70px;" value="CONTINUAR"></input>
                                </p>
                            </div>
                            <div id="id_set_title" style="display: none;">
                                <textarea name="page_title" id="editor" style="background: blue;">
                                    <div style='width: 100%; height: 300px; background-color: #052c9b !important'>
                                        <p class='mb-2' style='color: white; font-weight: bolder; font-size: 28px !important; line-height: 1;'>
                                            <strong>
                                                #StaCatarina <br>                  
                                                <span style="color: #F2994A;">
                                                    JUNTOS
                                                    </span>
                                                <br>
                                                <span>
                                                Prevenir está en <br>
                                                nuestras MANOS.
                                                </span>
                                            </strong>
                                        </p>
                                        <p style='line-height: 10px; font-size: 12px; color: white;' class='mb-0'><small>
                                            Ayúdanos a prevenir el contagio<br>
                                            del Coronavirus <strong>COVID 19</strong>.
                                            </small>
                                        </p>
                                    </div>
                                </textarea> 
                                
                            <!-- <section class="px-2 px-md-4 px-xl-5 text-white static-lateral">
                                
                                </section> -->
                                
                                <input class="w3-btn w3-black" type="submit" style="width: 100%; background-color: #042aa5 !important; margin-top: 70px;" name="add_new_form" value="CONTINUAR"></input>
                            </div>
                        </form>

                        
                    </div>
                </div>
            </div>            
                
            <?php
    }

    function add_js_script() {
        $version = rand(111,9999);
        wp_enqueue_style( 'fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), $version, 'all' );
        wp_enqueue_style( 'w3_css', 'https://www.w3schools.com/w3css/4/w3.css', array(), $version, 'all' );
        wp_enqueue_style( 'style', plugins_url( 'css/style.css', __FILE__ ), array(), $version, 'all' );
        wp_enqueue_script( 'jquery_js', "https://cdn.tiny.cloud/1/p8ae4l9arhl9cjvo28f706m8s7v3v5bn7qn7n1w3at4i6j6y/tinymce/5/tinymce.min.js", array('jquery'), $version, true);
        //wp_enqueue_script( 'tinymce', plugins_url( 'js/tinymce.min.js', __FILE__ ), array('jquery'), $version, true);
        wp_enqueue_script( 'grm_js', plugins_url( 'js/script.js', __FILE__ ), array('jquery'), $version, true);
        wp_localize_script( 'grm_js', 'grm_js_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ), 'grm_ajax_nonce' => wp_create_nonce('grm-fro-form-ajax'), 'grm_site_url' => site_url() ) );
    
    }    

    function my_theme_redirect() {
        global $wp;
        $plugindir = dirname( __FILE__ );

        $templatefilename = 'page-register-complete.php';
        if (file_exists(TEMPLATEPATH . '/' . $templatefilename)) {
            $return_template = TEMPLATEPATH . '/' . $templatefilename;
        } else {
            $return_template = $plugindir . '/include/' . $templatefilename;
        }
        do_theme_redirect($return_template);
    }

    function do_theme_redirect($url) {
        global $post, $wp_query;
        if (have_posts()) {
            include($url);
            die();
        } else {
            $wp_query->is_404 = true;
        }
    }
